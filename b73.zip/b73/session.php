<?php  
    session_start();

    $_SESSION['name'] = "Arup Sarkar";
    $_SESSION['age'] = 23;

    echo $_SESSION['name'];

    echo "<br>";

    $name = "Hasibur Rahman";
    // echo $name;

    session_unset();
    $_SESSION['name'] = "Hasibur Rahmanr";
    echo $_SESSION['name'];
?>