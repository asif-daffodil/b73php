<h1>This is a demo text</h1>
<?php  
 echo "<h2>This is another demo text</h2>","Hmmm<br>";
 print "Hello world";
?>