<?php  
    $name = "Asif Abir";
    echo $name;
    /*
    * $name
    * $_name
    * $na_me
    * $name123
    * $x
    * $123x -> we cant use number at the beginning of a veriable name
    */
?>