<?php
    //GLOBALS
    $hasib = "Chandpur";
    function hasibur() {
        echo $GLOBALS['hasib'];
    }
    hasibur();

    // function haa ($hasib) {
    //     echo $hasib;
    // }

    // haa ($hasib);
    
    // $_SERVER[]
    
    echo "<pre>";
    print_r($_SERVER);
    echo "</pre>";

    echo "<h1>".$_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF']."</h1>";
    echo "<h2>".$_SERVER['HTTP_SEC_CH_UA_PLATFORM']."</h2>";
    echo "<h3>".$_SERVER['REQUEST_METHOD']."</h3>";
    echo "<h4>".basename($_SERVER['PHP_SELF'])."</h4>";

    //$_GET
    // echo $_GET['h']." ".$_GET['r']; 
?>

<a href="<?= $_SERVER['PHP_SELF'].'?name=Hasibur%20Rahman&age=23' ?>">
    <button>Hasibur Rahman</button>
</a>
<a href="<?= $_SERVER['PHP_SELF'].'?name=Arup%20Sarkar&age=22' ?>">
    <button>Arup Sarkar</button>
</a>

<h3><?= $_GET['name'] ?? null; ?></h3>
<h4><?= $_GET['age'] ?? null; ?></h4>
<h5><?= (isset($_GET['name']) && isset($_GET['age']))? "Name : ".$_GET['name']."<br>Age : ".$_GET['age']: null; ?></h5>

<?php  
    session_start();
    echo $_SESSION['name'];

?>