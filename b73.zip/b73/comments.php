<?php  
    // single line comment
    "eta kintu comment hobena";
    # this is also a single line comment
    "etao kintu comment na";

    /* 
        this is a
        multiline 
        comment
        _______
    */
    /*
     * this is line one
     * this is line two
     * this is line three
     */
?>