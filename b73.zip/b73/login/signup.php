<?php  
    include_once("./header.php");
    (isset($_SESSION['email']))? header("location: index.php"): null;
    
    if (isset($_POST['sub123']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
      $email = safe($_POST['email']);
      $fname = safe($_POST['fname']);
      $pass = safe($_POST['pass']);
      $cpass = safe($_POST['cpass']);
      $gender = safe($_POST['gender'] ?? null) ;

        if (empty($fname)) {
          $errFname = "<span style='color:red;' >Please write your full name</span>";
        }elseif (strlen($fname) > 100) {
          $errFname = "<span style='color:red;' >Big names are not allowed</span>";
        }elseif (!preg_match("/^[A-Za-z. ]*$/", $fname)) {
          $errFname = "<span style='color:red;' >Invalid name</span>";
        }else{
          $crrFname = $fname;
        }
      
        if (empty($email)) {
          $errEmail = "<span style='color:red;' >Please write your email address</span>";
        }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          $errEmail = "<span style='color:red;' >Invalid email address</span>";
        }else{
          $crrEmail = $email;
        }

        if (empty($pass)) {
          $errPass = "<span style='color:red;' >Please write your password</span>";
        }elseif (strlen($pass) < 6) {
          $errPass = "<span style='color:red;' >Please write a strong password</span>";
        }else {
          $crrPass = $pass;
        }

        if(isset($crrPass)){
          if (empty($cpass)) {
            $errCpass = "<span style='color:red;' >Please write your confirm password</span>";
          }elseif (strlen($cpass) < 6) {
            $errCpass = "<span style='color:red;' >Please write a strong password</span>";
          }elseif($cpass != $crrPass){
            $errCpass = "<span style='color:red;' >Password didnot matched</span>";
          }else {
            $crrCpass = $cpass;
          }
        }
        
        $check_gender = ['Male', 'Female', 'Others'];
        if (empty($gender)) {
          $errGender = "<span style='color:red;' >Please select your gender</span>";
        }elseif(!in_array($gender, $check_gender)){
          $errGender = "<span style='color:red;' >Paknami bondho korun</span>";
        }else{
          $crrGender = $gender;
        }

        if (isset($crrFname) && isset($crrEmail) && isset($crrCpass) && isset($crrGender)){
          $_SESSION['email'] =  $crrEmail;
          $_SESSION['name'] = $crrFname;
          $success = "<div class='alert alert-success alert-dismissible'><button class='btn-close' data-bs-dismiss='alert'></button>Registration Successfull</div>";
          echo '<meta http-equiv="refresh" content="3;url=index.php" />';
        }
  }
    function safe($data){
      $data = htmlspecialchars($data);
      $data = trim($data);
      $data = stripslashes($data);
      return $data;
    }
?>
<div class="container">
    <div class="row py-5">
        <div class="col-md-8 m-auto border p-5 rounded shadow">
            <h3 class="mb-4">Sign-up Form</h3>
            <?= $err ??  $success ?? null; ?>
        <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
  <div class="row mb-3">
    <label for="inputEmail3" class="col-sm-3 col-form-label">Name</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" autocomplete="off" name="fname" value="<?= $fname ?? null; ?>">
      <?= $errFname ?? null; ?>
    </div>
  </div>
  <div class="row mb-3">
    <label for="inputEmail3" class="col-sm-3 col-form-label">Email</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" autocomplete="off" name="email" value="<?= $email ?? null; ?>">
      <?= $errEmail ?? null; ?>
    </div>
  </div>
  <div class="row mb-3">
    <label for="inputPassword3" class="col-sm-3 col-form-label">Password</label>
    <div class="col-sm-9">
      <input type="password" class="form-control" autocomplete="off" name="pass" value="<?= $pass ?? null; ?>">
      <?= $errPass ?? null; ?>
    </div>
  </div>
  <div class="row mb-3">
    <label for="inputPassword3" class="col-sm-3 col-form-label">Confirm Password</label>
    <div class="col-sm-9">
      <input type="password" class="form-control" autocomplete="off" name="cpass" value="<?= $cpass ?? null; ?>">
      <?= $errCpass ?? null; ?>
    </div>
  </div>
  <div class="row mb-3">
    <label for="inputPassword3" class="col-sm-3 col-form-label">Gender</label>
    <div class="col-sm-9">
      <div class="form-check form-check-inline">
        <input type="radio" class="form-check-input" name="gender" value="Male"  <?= (isset($gender) && $gender == 'Male')? 'checked':null ?>>
        <label for="" class="form-check-label">Male</label>
      </div>
      <div class="form-check form-check-inline">
        <input type="radio" class="form-check-input" name="gender" value="Female" <?= (isset($gender) && $gender == 'Female')? 'checked':null ?> >
        <label for="" class="form-check-label">Female</label>
      </div>
      <div class="form-check form-check-inline">
        <input type="radio" class="form-check-input" name="gender" value="Others" <?= (isset($gender) && $gender == 'Others')? 'checked':null ?> >
        <label for="" class="form-check-label">Others</label>
      </div>
      <div class="d-block"><?= $errGender ?? null; ?></div>
    </div>
  </div>
  <div class="row mb-3">
    <div class="col-sm-9 offset-sm-3">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" >
        <label class="form-check-label" for="gridCheck1">
          Remember Me
        </label>
      </div>
    </div>
  </div>
  <button type="submit" class="btn btn-primary" name="sub123">Sign up</button>
</form>
        </div>
    </div>
</div>

<?php  
    include_once("./footer.php");
?>