<?php  
    include_once("./header.php");
    if(!isset($_SESSION['email'])){
?>
    <div class="container">
        <div class="row min-vh-100 d-flex">
            <div class="col-md-8 m-auto fs-1 text-center">
                Please <a href="./login.php">login</a> to see this website!
            </div>
        </div>
    </div>
<?php }else{ include_once("./slider.php");?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12 h2">
            Home Page
        </div>
        <div class="col-md-12 fst-italic fw-lighter">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam repudiandae obcaecati saepe error debitis porro voluptates, quaerat ipsam voluptatum officia aut quis assumenda omnis voluptas corrupti distinctio, odit voluptatibus temporibus dignissimos perferendis iste? Quisquam quidem at commodi, saepe architecto accusamus consequatur laboriosam voluptatibus, id ea incidunt dolorum. Eum consequatur dolore culpa fugiat necessitatibus rem cum aperiam ab. Id vitae autem architecto iure doloribus vel. Atque at inventore quis possimus, eum qui sapiente natus! Laborum possimus quibusdam voluptas reprehenderit numquam enim laboriosam quidem ipsam, consequatur ducimus, unde odio expedita voluptates dolorum maiores! Explicabo voluptates, quos amet dolorum, fugit qui omnis voluptate ratione deleniti eligendi, pariatur possimus! Quae minima amet impedit temporibus exercitationem deserunt neque maiores quia? Consequuntur suscipit vitae ab aperiam fugit nesciunt voluptates explicabo sed, maxime provident quae debitis totam dicta autem quo reprehenderit commodi non! Corrupti, sit voluptatum! Laudantium exercitationem recusandae quis animi sequi ipsam quam magni quasi quaerat. <br>
            <a href="#" class="btn btn-primary btn-sm px-4 mt-3">Read More</a>
        </div>
    </div>
</div>
<?php } ?>
<?php  
    include_once("./footer.php");
?>


    