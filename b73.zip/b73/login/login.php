<?php  
    include_once("./header.php");
    (isset($_SESSION['email']))? header("location: index.php"): null;
    $pemail = "hasib@gmail.com";
    $ppass = "123456";
    if (isset($_POST['sub123']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
      $email = safe($_POST['email']);
      $pass = safe($_POST['pass']);
      
        if (empty($email)) {
          $errEmail = "<span style='color:red;' >Please write your email address</span>";
        }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          $errEmail = "<span style='color:red;' >Invalid email address</span>";
        }else{
          $crrEmail = $email;
        }

        if (empty($pass)) {
          $errPass = "<span style='color:red;' >Please write your password</span>";
        }elseif (strlen($pass) < 6) {
          $errPass = "<span style='color:red;' >Please write a strong password</span>";
        }else {
          $crrPass = $pass;
        }

        if (isset($crrEmail) && isset($crrPass)){
          if($crrEmail == $pemail && $crrPass == $ppass){
            $_SESSION['email'] =  $crrEmail;
            $_SESSION['name'] = "Hasibur Rahman";
            $success = "<div class='alert alert-success alert-dismissible'><button class='btn-close' data-bs-dismiss='alert'></button>Login Successfull</div>";
            echo '<meta http-equiv="refresh" content="3;url=index.php" />';
          }else{
            $err = "<div class='alert alert-danger alert-dismissible'><button class='btn-close' data-bs-dismiss='alert'></button>Email address or password is wrong</div>";
          }
        }
    }

    function safe($data){
      $data = htmlspecialchars($data);
      $data = trim($data);
      $data = stripslashes($data);
      return $data;
    }
?>
<div class="container">
    <div class="row py-5">
        <div class="col-md-6 m-auto border p-5 rounded shadow">
            <h3 class="mb-4">Login Form</h3>
            <?= $err ??  $success ?? null; ?>
        <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
  <div class="row mb-3">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" autocomplete="off" name="email" value="<?= $email ?? null; ?>">
      <?= $errEmail ?? null; ?>
    </div>
  </div>
  <div class="row mb-3">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" autocomplete="off" name="pass" value="<?= $pass ?? null; ?>">
      <?= $errPass ?? null; ?>
    </div>
  </div>
  <div class="row mb-3">
    <div class="col-sm-10 offset-sm-2">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" >
        <label class="form-check-label" for="gridCheck1">
          Remember Me
        </label>
      </div>
    </div>
  </div>
  <button type="submit" class="btn btn-primary" name="sub123">Login</button>
</form>
        </div>
    </div>
</div>

<?php  
    include_once("./footer.php");
?>