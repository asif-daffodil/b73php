<?php  
    // $x = 15;
    // $x = 16;
    // echo $x;

    define('xyz','Dhaka is the capital of Bangladesh');
    echo(xyz);
?>