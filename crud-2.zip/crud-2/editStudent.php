<?php 
    include_once('./header.php');
    if(!isset($_SESSION['uname'])){
        header('location: login.php');
    }
    if (!isset($_GET['id'])) {
        header('location: studentList.php');
    }else{
        $sid = $_GET['id'];
    }
    
    $select_query = "SELECT * FROM `students` WHERE `id` = $sid";
    $select = $conn->query($select_query);
    if ($select->num_rows != 1) {
        header('location: studentList.php');
    }
    $data = $select->fetch_object();
    $cities = ['Badarganj','Bajitpur', 'Bandarban','Baniachang','Barisal','Bera','Bhairab Bazar','Bhandaria','Bhatpara','Abhaynagar','Bheramara','Bhola','Bogra','Burhanuddin','Char Bhadrasan','Chhagalnaiya','Chhatak','Chilmari','Chittagong','Comilla','Cox\'s Bazar','Dhaka','Dinajpur','Dohar','Faridpur','Fatikchari','Feni','Gafargaon','Gaurnadi','Habiganj','Hajiganj','Ishurdi','Jamalpur','Jessore','Jhingergacha','Joypur Hat','Kalia','Kaliganj','Kesabpur','Khagrachhari','Khulna','Kishorganj','Kushtia','Laksham','Lakshmipur','Lalmanirhat','Lalmohan','Madaripur','Manikchari','Mathba','Maulavi Bazar','Mehendiganj','Mirzapur','Morrelgonj','Muktagacha','Mymensingh','Nabinagar','Nagarpur','Nageswari','Nalchiti','Narail','Narayanganj','Narsingdi','Nawabganj','Netrakona','Pabna','Palang','Panchagarh','Par Naogaon','Parbatipur','Patiya','Phultala','Pirgaaj','Pirojpur','Raipur','Rajshahi','Ramganj','Rangpur','Raojan','Saidpur','Sakhipur','Sandwip','Sarankhola','Sarishabari','Satkania','Satkhira','Shahzadpur','Sherpur','Shibganj','Sirajganj','Sylhet','Tangail','Teknaf','Thakurgaon','Tungi','Tungipara','Uttar Char Fasson'];
    if (isset($_POST['ssbtn'])) {
        $sname = sefuda($_POST['sname']);
        $sphone = sefuda($_POST['sphone']);
        $scity = sefuda($_POST['scity']);
        $gender = sefuda($_POST['gender'] ?? null);

        if(empty($sname)){
            $errName = "Please write your name";
        }elseif(!preg_match('/^[A-Za-z. ]*$/', $sname)){
            $errName = "Invalid name format";
        }else{
            $crrSname = $conn->real_escape_string($sname);
        }

        if (empty($sphone)) {
            $errPhone = 'Please provide the phone number';
        }elseif(!preg_match('/^[0-9+ ]*$/', $sphone) || strlen($sphone) < 11){
            $errPhone = "Invalid phone number";
        }else{
            $crrSphone = $conn->real_escape_string($sphone);
        }

        if(empty($scity)){
            $errCity = "Please select a city";
        }elseif(!in_array($scity, $cities)){
            $errCity = "Har bap ka ek bap hota hey";
        }else{
            $crrScity = $conn->real_escape_string($scity);
        }

        if (empty($gender)) {
            $errGender = '<span class="text-danger">Please select a gender</span>';
        }elseif(!in_array($gender, ['Male', 'Female'])){
            $errGender = '<span class="text-danger">Paknami bondho korun</span>';
        }else{
            $crrGender = $conn->real_escape_string($gender);
        }

        if (isset($crrSname) && isset($crrSphone) && isset($crrScity) && isset($crrGender)) {
           $update_query = "UPDATE `students` SET `name` = '$crrSname', `gender` = '$crrGender', `phone` = '$crrSphone', `city` = '$crrScity' WHERE id = $sid";
           $update = $conn->query($update_query);
           if (!$update) {
               $msg = "<div class='alert alert-danger alert-dismissible'><button class='btn-close' data-bs-dismiss='alert'></button>Something went wrong</div>";
           }else{
                $msg = "<div class='alert alert-success alert-dismissible'><button class='btn-close' data-bs-dismiss='alert'></button>Student updated successfully!</div>";
           }
        }
    }
?> 
    <div class="container">
      <div class="row mt-5 pt-5">
        <div class="col-md-6 m-auto border rounded shadow p-5">
          <h2 class="mb-4">Search Student</h2>
          <?= $msg ?? null; ?>
          <form action="" method="post">
            <input type="text" placeholder="Student Name" name="sname" class="form-control mb-2 <?= (isset($errName))? 'border-danger':null; ?>" value="<?= $data->name ?? $sname ?? null?>" data-bs-toggle="tooltip" title="<?= $errName ?? null; ?>">
            <input type="text" placeholder="Phone Number" name="sphone" class="form-control mb-2 <?= (isset($errPhone))? 'border-danger':null; ?>" value="<?= $data->phone ?? $sphone ?? null?>" data-bs-toggle="tooltip" title="<?= $errPhone ?? null; ?>">
            <select name="scity" class="form-select mb-2 <?= (isset($errCity))? 'border-danger':null; ?>" data-bs-toggle="tooltip" title="<?= $errCity ?? null; ?>">
                <option value="">--Select--</option>
                <?php foreach($cities as $citie){ ?>
                    <option value="<?= $citie; ?>" <?php if(isset($scity) &&$citie == $scity){echo 'selected';}elseif($data->city == $citie){echo 'selected';} ?> ><?= $citie; ?></option>
                <?php } ?>
            </select>
            <div class="mb-2">
                <div class="form-check form-check-inline">
                    <label class="form-check-label" for="">Gender : </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" id="inlineCheckbox1" value="Male" name="gender" <?php if(isset($gender) && $gender == "Male"){echo 'checked';}elseif($data->gender == 'Male'){echo 'checked';}  ?>>
                    <label class="form-check-label" for="">Male</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" id="inlineCheckbox1" value="Female" name="gender" <?php if(isset($gender) && $gender == "Female"){echo 'checked';}elseif($data->gender == 'Female'){echo 'checked';}  ?>>
                    <label class="form-check-label" for="">Female</label>
                </div>
                <div class="form-check form-check-inline"><?= $errGender ?? null; ?></div>
            </div>
            <input type="submit" value="Update Student" name="ssbtn" class="btn btn-sm btn-dark btn-outline-light py-3 px-4">
          </form>
        </div>
      </div>
    </div>
<?php include_once('./footer.php') ?> 
    