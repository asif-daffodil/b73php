<?php 
    include_once('./header.php');
    if (isset($_SESSION['uname'])) {
        header("location: index.php");
    } 
    if(isset($_POST['lbtn'])){
        $uname = sefuda($_POST['uname']);
        $pass = sefuda($_POST['pass']);
        if (empty($uname)) {
            $errUname = "<div class='alert alert-danger alert-dismissible mb-2'><button class='btn-close' data-bs-dismiss='alert'></button>Please write the username</div>";
        }else{
            $crrUserName = $conn->real_escape_string($uname);
        }
        if (empty($pass)) {
            $errPass = "<div class='alert alert-danger alert-dismissible'><button class='btn-close' data-bs-dismiss='alert'></button>Please write the password</div>";
        }else{
            $crrPass = $conn->real_escape_string(md5($pass));
        }

        if (isset($crrUserName) && isset($crrPass)) {
            $check_query = "SELECT * FROM `users` WHERE `uname` = '$crrUserName' AND `pass` = '$crrPass'";
            $check = $conn->query($check_query);
            if ($check->num_rows == 0) {
                $err = "<div class='alert alert-danger alert-dismissible'><button class='btn-close' data-bs-dismiss='alert'></button>Username or password is not correct</div>";
            }else{
                $success = "<div class='alert alert-success alert-dismissible'><button class='btn-close' data-bs-dismiss='alert'></button>Login Successfull</div><meta http-equiv='refresh' content='2;url=./index.php' />";
                $_SESSION['uname'] = $crrUserName;
            }
        }
    }
?> 
    <div class="container">
      <div class="row mt-5 pt-5">
        <div class="col-md-6 m-auto border rounded shadow p-5">
            <?= $errUname ?? null; ?>
            <?= $errPass ?? null; ?>
            <?= $err ?? $success ?? null; ?>
          <h2 class="mb-4">Login Form</h2>
          <form action="" method="post">
            <input type="text" placeholder="Username" name="uname" class="form-control mb-2" value="<?= $uname ?? null; ?>">
            <input type="password" placeholder="Password" name="pass" class="form-control mb-2" value="<?= $pass ?? null; ?>">
            <input type="submit" value="Login" name="lbtn" class="btn btn-sm btn-dark btn-outline-light py-3 px-4">
          </form>
        </div>
      </div>
    </div>
<?php include_once('./footer.php') ?> 
    