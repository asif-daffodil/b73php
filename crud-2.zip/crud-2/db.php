<?php 
    $conn = mysqli_connect('localhost','root','','b73crud2');
?>