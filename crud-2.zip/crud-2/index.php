<?php include_once('./header.php'); ?> 
    <div class="container">
      <div class="row mt-5 pt-5">
        <div class="col-md-6 m-auto border rounded shadow p-5">
          <h2 class="mb-4">Search Student</h2>
          <form action="" method="post">
            <input type="text" placeholder="Search Student by name" name="sname" class="form-control mb-2">
            <input type="submit" value="Search Student" name="ssbtn" class="btn btn-sm btn-dark btn-outline-light py-3 px-4">
          </form>
        </div>
      </div>
    </div>
<?php include_once('./footer.php') ?> 
    