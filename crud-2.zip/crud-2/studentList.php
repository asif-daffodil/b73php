<?php 
    include_once('./header.php');
    if(!isset($_SESSION['uname'])){
        header('location: login.php');
    }
    $select_query = "SELECT * FROM `students`";
    $select = $conn->query($select_query);

    if (!isset($_GET['page'])) {
        header('location: studentList.php?page=1');
    }else{
        $pageNo = $_GET['page'];
    }
    
    $total_student = $select->num_rows;
    $studentPerPage = 5;
    $total_pages = ceil($total_student/$studentPerPage);
    $start_point = ($pageNo-1)*$studentPerPage;
    $select_ayon_query = "SELECT * FROM `students` LIMIT $start_point, $studentPerPage";
    $select_ayon = $conn->query($select_ayon_query);
    if ($pageNo > $total_pages) {
        header('location: studentList.php?page=1');
    }
?> 
    <div class="container">
      <div class="row mt-5 pt-5">
        <div class="col-md-8 m-auto border rounded shadow p-5">
          <h2 class="mb-4">Student List</h2>
          <?php  
            if ($select->num_rows == 0) {
                echo "<div class='display-4'>No Student Record found</div>";
            }else{
          ?>
            <table class="table table-dark table-striped table-hover">
                <tr>
                    <th>S.N</th>
                    <th>Student Name</th>
                    <th>Gender</th>
                    <th>Phone</th>
                    <th>City</th>
                    <th>Registion Date</th>
                    <th>Action</th>
                </tr>
                <?php $x = $start_point+1; while ($data = $select_ayon->fetch_object() ) {?>
                    <tr>
                        <td><?= $x ?></td>
                        <td><?= $data->name; ?></td>
                        <td><?= $data->gender; ?></td>
                        <td><?= $data->phone; ?></td>
                        <td><?= $data->city; ?></td>
                        <td><?= date('d-M-Y', strtotime($data->created_at)) ?></td>
                        <td>
                            <a href="./editStudent.php?id=<?= $data->id; ?>" class="btn btn-sm btn-warning"><i class="far fa-edit"></i></a>
                            <a href="./studentDelete.php?id=<?= $data->id; ?>" class="btn btn-sm btn-danger"><i class="far fa-trash-alt"></i></a>
                        </td>
                    </tr>
                <?php $x++; } ?>
            </table>
          <?php } ?>
        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item"><a class="page-link <?= ($pageNo == 1)? 'd-none':null; ?>" href="./studentList.php?page=<?= ($pageNo != 1)? ($pageNo -1):1; ?>">Previous</a></li>
                <?php for($i = 1; $i <= $total_pages; $i++){ ?>
                <li class="page-item"><a class="page-link" href="./studentList.php?page=<?= $i; ?>"><?= $i; ?></a></li>
                <?php } ?>
                <li class="page-item"><a class="page-link <?= ($pageNo == $total_pages)? 'd-none':null; ?>" href="./studentList.php?page=<?= ($pageNo != $total_pages)? ($pageNo +1):$total_pages; ?>">Next</a></li>
            </ul>
        </nav>
        </div>
      </div>
    </div>
<?php include_once('./footer.php') ?> 
    