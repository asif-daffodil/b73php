-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2021 at 04:57 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `b73crud2`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `gender`, `phone`, `city`, `created_at`) VALUES
(1, 'Hasibur Rahman', 'Male', '017420420420', 'Feni', '2021-10-25 15:05:21'),
(2, 'Arup Sarker', 'Male', '01955517560', 'Chilmari', '2021-10-25 15:06:19'),
(3, 'Ragib Ayon', 'Male', '0173108400834', 'Burhanuddin', '2021-10-26 12:17:39'),
(4, 'Sadia Bithi', 'Female', '01978945612', 'Jessore', '2021-10-26 12:19:58'),
(5, 'Kamal Moa', 'Male', '017420420420', 'Tungi', '2021-10-26 12:20:32'),
(6, 'Jamal Khan', 'Male', '01978945612', 'Tungipara', '2021-10-26 12:20:46'),
(7, 'Toamal Chowdhury', 'Male', '017420420420', 'Chilmari', '2021-10-26 12:21:00'),
(8, 'Nabhan Abdullah', 'Male', '01955517560', 'Sakhipur', '2021-10-26 12:21:12'),
(9, 'Ariyan Khan', 'Male', '016354879854', 'Chittagong', '2021-10-26 12:35:59'),
(10, 'Jalal Uddin', 'Male', '01955517560', 'Cox\'s Bazar', '2021-10-26 12:36:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(100) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `uname`, `pass`, `created_at`) VALUES
(1, 'asif', 'e10adc3949ba59abbe56e057f20f883e', '2021-10-25 12:53:22'),
(2, 'hasib', 'e10adc3949ba59abbe56e057f20f883e', '2021-10-25 13:07:26');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
