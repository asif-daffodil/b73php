<?php 
    include_once('./header.php');
    if(!isset($_SESSION['uname'])){
        header('location: login.php');
    }
    if (!isset($_GET['id'])) {
        header('location: studentList.php');
    }else{
        $sid = $_GET['id'];
    }
    $select_query = "SELECT * FROM `students` WHERE `id` = $sid";
    $select = $conn->query($select_query);
    if ($select->num_rows != 1) {
        header('location: studentList.php');
    }

    if(isset($_POST['sub123'])){
       $stuid = sefuda($_POST['stuid']);
       $delete_query = "DELETE FROM `students` WHERE id = $stuid";
       $delete = $conn->query($delete_query);
       if (!$delete) {
        $msg = "<div class='alert alert-danger alert-dismissible mt-3'><button class='btn-close' data-bs-dismiss='alert'></button>Something went wrong</div>";
        }else{
        $msg = "<div class='alert alert-success alert-dismissible mt-3'><button class='btn-close' data-bs-dismiss='alert'></button>Student deleted successfully</div><meta http-equiv='refresh' content='2;url=./studentList.php' />";
        }
    }
?> 
    <div class="container">
      <div class="row mt-5 pt-5">
        <div class="col-md-6 m-auto border rounded shadow p-5 text-center">
          <h2 class="mb-4 text-danger">Do you realy want to delete the student?</h2>
          <form action="" method="post">
            <input type="hidden" value="<?= $sid; ?>" name="stuid">
           <button type="submit" class="btn btn-danger" name="sub123">Yes</button>
           <button type="button" class="btn btn-success" onclick="history.go(-1);">No</button>
          </form>
          <?= $msg ?? null; ?>
        </div>
      </div>
    </div>
<?php include_once('./footer.php') ?> 
    